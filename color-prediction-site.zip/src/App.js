import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center px-4 py-6 sm:px-6">
      <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-full sm:max-w-md text-center">
        <h1 className="text-3xl font-bold text-purple-600 mb-4">🎯 Color Prediction Game</h1>
        <p className="text-gray-700 mb-6">Predict the next color and win double!</p>

        <div className="flex justify-around mb-6">
          <button className="bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2 rounded-xl">Red</button>
          <button className="bg-green-500 hover:bg-green-600 text-white font-semibold px-4 py-2 rounded-xl">Green</button>
          <button className="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-4 py-2 rounded-xl">Violet</button>
        </div>

        <div className="text-sm text-gray-600">
          <p>⏰ Next Round In: <span className="font-semibold">02:58</span></p>
          <p className="mt-2">💰 Current Balance: <span className="font-bold text-green-600">৳1250</span></p>
        </div>

        <div className="mt-6">
          <button className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-2xl">Add Balance</button>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-full sm:max-w-md text-center mt-6">
        <h2 className="text-2xl font-bold text-blue-600 mb-4">🔐 Login / Signup</h2>
        <input
          type="text"
          placeholder="Phone Number"
          className="border border-gray-300 rounded-xl px-4 py-2 w-full mb-4"
        />
        <input
          type="password"
          placeholder="Password"
          className="border border-gray-300 rounded-xl px-4 py-2 w-full mb-4"
        />
        <button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-xl w-full">
          Login
        </button>
        <p className="text-sm text-gray-500 mt-4">
          Don't have an account? <span className="text-blue-600 underline cursor-pointer">Sign up</span>
        </p>
      </div>

      <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-full sm:max-w-md text-left mt-6">
        <h2 className="text-xl font-bold text-gray-800 mb-4">📜 Bet History</h2>
        <ul className="text-sm text-gray-600 space-y-2">
          <li className="flex justify-between">
            <span>12:00 PM</span>
            <span>🔴 Red</span>
            <span className="text-green-600 font-semibold">+৳100</span>
          </li>
          <li className="flex justify-between">
            <span>12:03 PM</span>
            <span>🟢 Green</span>
            <span className="text-red-500 font-semibold">-৳50</span>
          </li>
          <li className="flex justify-between">
            <span>12:06 PM</span>
            <span>🟡 Violet</span>
            <span className="text-green-600 font-semibold">+৳200</span>
          </li>
        </ul>
      </div>
    </div>
  );
}